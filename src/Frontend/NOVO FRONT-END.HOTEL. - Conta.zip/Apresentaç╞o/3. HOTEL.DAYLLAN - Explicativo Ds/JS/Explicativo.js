// COLOCAR O NOME DA PASTA ONDE ESTÁ O HTML E/OU LINK DA PAGINA PARA ONDE O BOTÃO DEVE IR
function changePage(){
    window.location = 'https://blog.softensistemas.com.br/conhecimento-habilidade-e-atitude/';
}