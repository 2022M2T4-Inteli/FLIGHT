
function changePage1(){
    window.location='file:///C:/Users/Inteli/Desktop/DESENVOLVIMENTO%20WEB/NOVAS%20TELAS%20-%20DAYLLAN/Apresenta%C3%A7%C3%A3o/10.%20HOTEL.DAYLLAN%20-%20Agendamento%20finalizado/HTML/Agendamento%20Finalizado.html'
}