
function changePage(){
    window.location='file:///C:/Users/Inteli/Desktop/DESENVOLVIMENTO%20WEB/NOVAS%20TELAS%20-%20DAYLLAN/HOTEL.JORDAN%20-%20Conta/HTML/mainHoteleiro.html'
}