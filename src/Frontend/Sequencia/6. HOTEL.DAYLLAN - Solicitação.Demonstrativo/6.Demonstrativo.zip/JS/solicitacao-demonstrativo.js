function changePage(){
    window.location = 'file:///C:/Users/Inteli/Desktop/DESENVOLVIMENTO%20WEB/NOVAS%20TELAS%20-%20DAYLLAN/Apresenta%C3%A7%C3%A3o/7.%20HOTEL.HENRI%20-%20Senha/HTML/Senha.html';
}