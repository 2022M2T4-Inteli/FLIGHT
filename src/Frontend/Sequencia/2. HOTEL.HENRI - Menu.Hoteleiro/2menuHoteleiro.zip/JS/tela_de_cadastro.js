function changePage(){
    window.location = '';
}

function changePage1(){
    window.location = 'file:///C:/Users/Inteli/Desktop/DESENVOLVIMENTO%20WEB/NOVAS%20TELAS%20-%20DAYLLAN/HOTEL.JORDAN%20-%20Conta/HTML/mainHoteleiro.html';
}

function changePage2(){
    window.location = '';
}

function changePage3(){
    window.location = 'file:///C:/Users/Inteli/Desktop/DESENVOLVIMENTO%20WEB/NOVAS%20TELAS%20-%20DAYLLAN/Apresenta%C3%A7%C3%A3o/9.%20HOTEL.DAYLLAN%20-%20Agendamento%20de%20Antecipa%C3%A7%C3%A3o/HTML/Agendamento%20de%20Antecipa%C3%A7%C3%A3o.html';
}

function changePage4(){
    window.location = 'file:///C:/Users/Inteli/Desktop/DESENVOLVIMENTO%20WEB/NOVAS%20TELAS%20-%20DAYLLAN/Apresenta%C3%A7%C3%A3o/3.%20HOTEL.DAYLLAN%20-%20Explicativo%20Ds/HTML/Explicativo%20Ds.html';
}

function changePage5(){
    window.location = '';
}