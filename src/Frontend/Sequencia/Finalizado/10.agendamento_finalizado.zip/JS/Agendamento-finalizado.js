function changepage(){
    window.location='file:///C:/Users/Inteli/Desktop/DESENVOLVIMENTO%20WEB/NOVAS%20TELAS%20-%20DAYLLAN/Apresenta%C3%A7%C3%A3o/8.%20HOTEL.DAYLLAN%20-%20Feedback/HTML/Feedback.html'
}