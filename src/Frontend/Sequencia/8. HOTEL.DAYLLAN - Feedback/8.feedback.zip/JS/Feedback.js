
function changePage(){
    window.location='file:///C:/Users/Inteli/Documents/GitHub/2022.M2.T4-PROJETO4/src/Frontend/Sequencia/1.%20HOTEL.JORDAN%20-%20Conta/HTML/mainHoteleiro.html'
}