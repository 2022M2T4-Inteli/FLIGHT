
function changePage1(){
    window.location='file:///C:/Users/Inteli/Documents/GitHub/2022.M2.T4-PROJETO4/src/Frontend/Sequencia/10.%20HOTEL.DAYLLAN%20-%20Agendamento%20finalizado/HTML/Agendamento%20Finalizado.html'
}